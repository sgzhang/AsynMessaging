package com.sgzhang.test.task;

public interface Task {
	public void complete();
}